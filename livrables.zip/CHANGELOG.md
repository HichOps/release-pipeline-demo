# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### 1.2.2 (2025-04-25)

## [1.2.0](https://github.com/HichOps/release-pipeline-demo/compare/v1.0.0...v1.2.0) (2025-04-25)


### Features

* modifications avant release ([0d834d4](https://github.com/HichOps/release-pipeline-demo/commit/0d834d4cc5e626150fa6a0a44e218b9ae07b9e62))

## 1.0.0 (2025-04-25)

* Initial commit: setup base project with Jest ([91f67ce](https://github.com/HichOps/release-pipeline-demo/commit/91f67ce))
* modif release-it sans login ([8a5a724](https://github.com/HichOps/release-pipeline-demo/commit/8a5a724))
* Release 1.1.0 ([df20e26](https://github.com/HichOps/release-pipeline-demo/commit/df20e26))
* chore: add .gitattributes to normalize line endings ([d7a051c](https://github.com/HichOps/release-pipeline-demo/commit/d7a051c))
* feat: add login button ([44a4602](https://github.com/HichOps/release-pipeline-demo/commit/44a4602))
